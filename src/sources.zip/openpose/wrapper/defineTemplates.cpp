#include <openpose/wrapper/headers.hpp>

namespace op
{
    template class Wrapper<DATUM_BASE_NO_PTR>;
}
