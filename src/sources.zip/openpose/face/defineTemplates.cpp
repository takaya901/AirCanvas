#include <openpose/face/headers.hpp>

namespace op
{
    DEFINE_TEMPLATE_DATUM(WFaceDetector);
    DEFINE_TEMPLATE_DATUM(WFaceExtractor);
    DEFINE_TEMPLATE_DATUM(WFaceRenderer);
}
