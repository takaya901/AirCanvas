#include <opencv2/highgui/highgui.hpp> // cv::imshow, cv::waitKey, cv::namedWindow, cv::setWindowProperty
#include <openpose/utilities/errorAndLog.hpp>
#include <openpose/gui/frameDisplayer.hpp>
#include <openpose/utilities/keypoint.hpp>
#include <opencv2/opencv.hpp>
#include <math.h>
#include <stdlib.h>
#define PI 3.14159265258979

#define M 0
#define T 1
#define Z 2
#define F 3
#define N 4
#define O 5
#define S 6
#define B 7

namespace op
{
    FrameDisplayer::FrameDisplayer(const Point<int>& windowedSize, const std::string& windowedName, const bool fullScreen) :
        mWindowedSize{windowedSize},
        mWindowName{windowedName},
        mGuiDisplayMode{(fullScreen ? GuiDisplayMode::FullScreen : GuiDisplayMode::Windowed)}
    {
    }

    void FrameDisplayer::initializationOnThread()
    {
        try
        {
            setGuiDisplayMode(mGuiDisplayMode);

            const cv::Mat blackFrame{mWindowedSize.y, mWindowedSize.x, CV_32FC3, {0,0,0}};
            FrameDisplayer::displayFrame(blackFrame);
            cv::waitKey(1); // This one will show most probably a white image (I guess the program does not have time to render in 1 msec)
            // cv::waitKey(1000); // This one will show the desired black image
        }
        catch (const std::exception& e)
        {
            error(e.what(), __LINE__, __FUNCTION__, __FILE__);
        }
    }

    void FrameDisplayer::setGuiDisplayMode(const GuiDisplayMode displayMode)
    {
        try
        {
            mGuiDisplayMode = displayMode;

            // Setting output resolution
            cv::namedWindow(mWindowName, CV_WINDOW_NORMAL | CV_WINDOW_KEEPRATIO);
            if (mGuiDisplayMode == GuiDisplayMode::FullScreen)
                cv::setWindowProperty(mWindowName, CV_WND_PROP_FULLSCREEN, CV_WINDOW_FULLSCREEN);
            else if (mGuiDisplayMode == GuiDisplayMode::Windowed)
            {
                cv::resizeWindow(mWindowName, mWindowedSize.x, mWindowedSize.y);
                cv::setWindowProperty(mWindowName, CV_WND_PROP_FULLSCREEN, CV_WINDOW_NORMAL);
            }
            else
                error("Unknown GuiDisplayMode", __LINE__, __FUNCTION__, __FILE__);
        }
        catch (const std::exception& e)
        {
            error(e.what(), __LINE__, __FUNCTION__, __FILE__);
        }
    }

    void FrameDisplayer::switchGuiDisplayMode()
    {
        try
        {
            if (mGuiDisplayMode == GuiDisplayMode::FullScreen)
                setGuiDisplayMode(GuiDisplayMode::Windowed);
            else if (mGuiDisplayMode == GuiDisplayMode::Windowed)
                setGuiDisplayMode(GuiDisplayMode::FullScreen);
            else
                error("Unknown GuiDisplayMode", __LINE__, __FUNCTION__, __FILE__);
        }
        catch (const std::exception& e)
        {
            error(e.what(), __LINE__, __FUNCTION__, __FILE__);
        }
    }

	/*�摜��\��t����*/
	void paste(cv::Mat dst, cv::Mat src, int x, int y, int width, int height) {
		cv::Mat resized_img;
		cv::resize(src, resized_img, cv::Size(width, height));

		if (x >= dst.cols || y >= dst.rows) return;
		int w = (x >= 0) ? std::min(dst.cols - x, resized_img.cols) : std::min(std::max(resized_img.cols + x, 0), dst.cols);
		int h = (y >= 0) ? std::min(dst.rows - y, resized_img.rows) : std::min(std::max(resized_img.rows + y, 0), dst.rows);
		int u = (x >= 0) ? 0 : std::min(-x, resized_img.cols - 1);
		int v = (y >= 0) ? 0 : std::min(-y, resized_img.rows - 1);
		int px = std::max(x, 0);
		int py = std::max(y, 0);

		cv::Mat roi_dst = dst(cv::Rect(px, py, w, h));
		cv::Mat roi_resized = resized_img(cv::Rect(u, v, w, h));
		roi_resized.copyTo(roi_dst);
	}


    void FrameDisplayer::displayFrame(const cv::Mat& frame, const int waitKeyValue)
    {
		int i=0;
		int mask_type = M;
		int m_scale = 20;	//�傫���قǃ��U�C�N���e���Ȃ�
		cv::Rect rect;		//��̈��؂�o��
		cv::Mat mask_img;	//�}�X�N�摜
		int mask_width = (LShoulder[i].x - RShoulder[i].x) / 2;
		int mask_height = head_bottom[i].y - head_top[i].y;

		/*�������牺��for���ȊO�̂Ƃ��낪�ǉ���*/
		cv::Mat head;
		cv::Mat body;
		cv::Mat Rleg;
		cv::Mat Lleg;
		cv::Mat Rarm;
		cv::Mat Larm;
		cv::Mat tmp1;
		cv::Mat tmp2;
		cv::Mat mask_head;
		cv::Mat mask_body;
		cv::Mat mask_Rarm;
		cv::Mat mask_Larm;
		cv::Mat mask_Rleg;
		cv::Mat mask_Lleg;
		cv::Mat black;
		int body_width = 0;
		int body_height = 0;
		int Rleg_width = 0;
		int Rleg_height = 0;
		int Lleg_width = 0;
		int Lleg_height = 0;
		int RArm_width = 0;
		int RArm_height= 0;
		int RArm_distance = 0;
		int LArm_width = 0;
		int LArm_height = 0;

		try
		{
			for (i = 0;i <= n;i++)
			{
				if (mask_type == B) {
					//�̂̍��W���畝�ƍ������v�Z
					mask_width = abs((LShoulder[i].x - RShoulder[i].x) / 2);
					mask_height = abs(head_bottom[i].y - head_top[i].y);
					body_width = abs(LShoulder[i].x - RShoulder[i].x);
					body_height = abs(rWest[i].y - RShoulder[i].y);
					Rleg_width = abs(body_width / 2);
					Rleg_height = abs(RAnkle[i].y - rWest[i].y);
					Lleg_width = abs(body_width / 2);
					Lleg_height = abs(LAnkle[i].y - lWest[i].y);
					RArm_height = abs(RWrist[i].y - RShoulder[i].y);
					RArm_width = Rleg_width / 2;
					LArm_height = abs(LWrist[i].y - LShoulder[i].y);
					LArm_width = Lleg_width / 2;
					//�̂ɏd�˂�p�̉摜�̓ǂݍ���
					head = cv::imread("examples/media/head.jpg"); 
					body = cv::imread("examples/media/body.jpg"); 
					Rleg = cv::imread("examples/media/Rleg.jpg"); 
					Lleg = cv::imread("examples/media/Lleg.jpg"); 
					Larm = cv::imread("examples/media/Larm.jpg"); 
					Rarm = cv::imread("examples/media/Rtest.png"); 
					//�}�X�N�p�̉摜�̓ǂݍ���
					black = cv::imread("examples/media/test.png");
					mask_head = cv::imread("examples/media/mask_head.jpg");
					mask_body = cv::imread("examples/media/mask_body.jpg");
					mask_Rarm = cv::imread("examples/media/mask_Rarm.jpg");
					mask_Larm = cv::imread("examples/media/mask_Larm.jpg");
					mask_Rleg = cv::imread("examples/media/mask_Rleg.jpg");
					mask_Lleg = cv::imread("examples/media/mask_Lleg.jpg");
					//���̏���
					if ((head_top[i].x - mask_width / 2) > 0 && head_top[i].y - 10 > 0 && mask_width > 0 && mask_height > 0) {
						//�}�X�N����
						tmp1 = frame.clone(); //�R�s�[
						tmp2 = frame.clone();
						paste(tmp1, black, 0, 0, tmp1.cols, tmp1.rows); //���T�C�Y�̐^�����ȉ�ʂ��쐬
						paste(tmp2, black, 0, 0, tmp2.cols, tmp2.rows);
						paste(tmp1, mask_head, head_top[i].x - mask_width / 2, head_top[i].y - 10, mask_width, mask_height + 50); //�����ɓ��̕���������
						paste(tmp2, head, head_top[i].x - mask_width / 2, head_top[i].y - 10, mask_width, mask_height + 50); //�����ɓ��̉摜
						cv::bitwise_and(tmp1, tmp2, tmp2); //��񖇂̃}�X�N���Ƃ邱�ƂŔw�i�^�����ȓ��̉摜���쐬(�T�C�Y��frame)
						cv::bitwise_not(tmp1, tmp1); //���n�ɓ��̕���������
						cv::bitwise_and(tmp1, frame, tmp1); //�w�i�ɓ��̕���������
						cv::bitwise_or(tmp1, tmp2, frame); //�񖇂̉摜�𑫂�
						//debug
						//cv::imshow("tmp1", tmp1);
						//cv::imshow("tmp2", tmp2);
					}
					//�̂̏���
					if (body_height > 0 && body_width > 0 && RShoulder[i].x > 0 && RShoulder[i].y - 25 > 0) {
						//�}�X�N����
						tmp1 = frame.clone();
						tmp2 = frame.clone();
						paste(tmp1, black, 0, 0, tmp1.cols, tmp1.rows);
						paste(tmp2, black, 0, 0, tmp2.cols, tmp2.rows);
						paste(tmp1, mask_body, RShoulder[i].x, RShoulder[i].y - 25, body_width, body_height + 25);
						paste(tmp2, body, RShoulder[i].x, RShoulder[i].y - 25, body_width, body_height + 25);
						cv::bitwise_and(tmp1, tmp2, tmp2);
						cv::bitwise_not(tmp1, tmp1);
						cv::bitwise_and(tmp1, frame, tmp1);
						cv::bitwise_or(tmp1, tmp2, frame);
					}
					//�E���̏���
					if (Rleg_height > 0 && Rleg_width > 0 && rWest[i].x - 25 > 0 && rWest[i].y - 75 > 0) {
						tmp1 = frame.clone();
						tmp2 = frame.clone();
						paste(tmp1, black, 0, 0, tmp1.cols, tmp1.rows);
						paste(tmp2, black, 0, 0, tmp2.cols, tmp2.rows);
						paste(tmp1, mask_Rleg, rWest[i].x - 25, rWest[i].y - 25, Rleg_width, Rleg_height + 75);
						paste(tmp2, Rleg, rWest[i].x - 25, rWest[i].y - 25, Rleg_width, Rleg_height + 75);
						cv::bitwise_and(tmp1, tmp2, tmp2);
						cv::bitwise_not(tmp1, tmp1);
						cv::bitwise_and(tmp1, frame, tmp1);
						cv::bitwise_or(tmp1, tmp2, frame);
					}
					//�����̏���
					if (Lleg_height > 0 && Lleg_width > 0 && rWest[i].x - 25 > 0 && rWest[i].y - 75 > 0) {
						tmp1 = frame.clone();
						tmp2 = frame.clone();
						paste(tmp1, black, 0, 0, tmp1.cols, tmp1.rows);
						paste(tmp2, black, 0, 0, tmp2.cols, tmp2.rows);
						paste(tmp1, mask_Lleg, rWest[i].x - 25 + Lleg_width, rWest[i].y - 25, Lleg_width, Lleg_height + 75);
						paste(tmp2, Lleg, rWest[i].x - 25 + Lleg_width, rWest[i].y - 25, Lleg_width, Lleg_height + 75);
						cv::bitwise_and(tmp1, tmp2, tmp2);
						cv::bitwise_not(tmp1, tmp1);
						cv::bitwise_and(tmp1, frame, tmp1);
						cv::bitwise_or(tmp1, tmp2, frame);
						}
					//���r�̏���
					if (LShoulder[i].x - 15 > 0 && LShoulder[i].y - 25 > 0) {
						tmp1 = frame.clone();
						tmp2 = frame.clone();
						paste(tmp1, black, 0, 0, tmp1.cols, tmp1.rows);
						paste(tmp2, black, 0, 0, tmp2.cols, tmp2.rows);
						paste(tmp1, mask_Larm, LShoulder[i].x - 15, LShoulder[i].y - 25, LArm_width + 10, LArm_height + 75);
						paste(tmp2, Larm, LShoulder[i].x - 15, LShoulder[i].y - 25, LArm_width + 10, LArm_height + 75);
						cv::bitwise_and(tmp1, tmp2, tmp2);
						cv::bitwise_not(tmp1, tmp1);
						cv::bitwise_and(tmp1, frame, tmp1);
						cv::bitwise_or(tmp1, tmp2, frame);
					}
					//�E�r�̏���
					if (RShoulder[i].x - 15 > 0 && RShoulder[i].y - 25 > 0) {
						tmp1 = frame.clone();
						tmp2 = frame.clone();
						paste(tmp1, black, 0, 0, tmp1.cols, tmp1.rows);
						paste(tmp2, black, 0, 0, tmp2.cols, tmp2.rows);
						paste(tmp1, mask_Rarm, RShoulder[i].x - 25, RShoulder[i].y - 25, RArm_width + 10, RArm_height + 75);
						paste(tmp2, Rarm, RShoulder[i].x - 25, RShoulder[i].y - 25, RArm_width + 10, RArm_height + 75);
						cv::bitwise_and(tmp1, tmp2, tmp2);
						cv::bitwise_not(tmp1, tmp1);
						cv::bitwise_and(tmp1, frame, tmp1);
						cv::bitwise_or(tmp1, tmp2, frame);
					}
					//�������Ԃɍ���Ȃ��H
						////�E�r�̏���
						//RArm_height = abs(RWrist[i].y - RShoulder[i].y)*2;
						//RArm_width = abs(RWrist[i].x - RShoulder[i].x)*2;
						//  //���Ǝ�̓�_�Ԃ̋���
						//RArm_distance = hypot( (RWrist[i].x - RShoulder[i].x), (RWrist[i].y - RShoulder[i].y)*2 );
						//RArm = cv::imread("examples/media/Rarm.jpg"); // �摜�̓ǂݍ���
						//double degree = atan2(RShoulder[i].y - RWrist[i].y, RShoulder[i].x - RWrist[i].x);
						//degree = 265 - degree * (180 / PI);
						//cv::Point2f center(RArm.cols*0.5, 0.0);
						//const cv::Mat affine_matrix = cv::getRotationMatrix2D(center, degree, 1.0);
						//cv::Mat dst_img;
						//cv::warpAffine(RArm, dst_img, affine_matrix, mask_img.size());
						//if ( (RShoulder[i].x - (RArm_width+50)) > 0 && (RShoulder[i].y - (RArm_height+25) ) > 0)
						//	paste(frame, RArm, RShoulder[i].x - (RArm_width/2+50), RShoulder[i].y - (RArm_height+25), RArm_width + 10, RArm_height + 75);

				}

				//�烂�U�C�N
				if (mask_type == M) {
					rect = cv::Rect(RShoulder[i].x, head_top[i].y, 100, 100);
					mask_img = cv::Mat(frame, rect).clone();
					//���U�C�N����
					cv::resize(mask_img, mask_img, cv::Size(), (double)1 / m_scale, (double)1 / m_scale);
					cv::resize(mask_img, mask_img, cv::Size(), m_scale, m_scale, cv::INTER_NEAREST);
				}
				//�Ǖ����U�C�N
				if (mask_type == N) {
					rect = cv::Rect(rWest[i].x, rWest[i].y, 200, 200);
					mask_img = cv::Mat(frame, rect).clone();
					//���U�C�N����
					cv::resize(mask_img, mask_img, cv::Size(), (double)1 / m_scale, (double)1 / m_scale);
					cv::resize(mask_img, mask_img, cv::Size(), m_scale, m_scale, cv::INTER_NEAREST);
				}
				//�������
				else if (mask_type == T) {
					rect = cv::Rect(head_top[i].x + 100, head_top[i].y, 10, 10);
					mask_img = cv::Mat(frame, rect).clone();
				}
				//���m����
				else if (mask_type == F) {
					mask_img = cv::imread("examples/media/fukushi.png"); // �摜�̓ǂݍ���
					if (mask_img.empty())
						printf("mask image is empty.\n");
				}
				//zombie
				else if (mask_type == Z) {
					mask_img = cv::imread("examples/media/head.jpg"); // �摜�̓ǂݍ���
					if (mask_img.empty())
						printf("mask image is empty.\n");
				}
				//�S�̎�
				else if (mask_type == O) {
					mask_img = cv::imread("examples/media/oninote.jpg"); // �摜�̓ǂݍ���
					if (mask_img.empty())
						printf("mask image is empty.\n");
				}
				//�S�g�]���r
				else if (mask_type == S) {
					mask_img = cv::imread("examples/media/zombie_stand2.png", cv::IMREAD_UNCHANGED); // �摜�̓ǂݍ���
					if (mask_img.empty())
						printf("mask image is empty.\n");
					mask_height = RAnkle[i].y - head_top[i].y;
					mask_width = mask_height * 0.3;
				}
					
				//�}�X�N�摜���d�˂�
				if (mask_type == N) {
					paste(frame, mask_img, rWest[i].x, rWest[i].y, 200, 200);
					//����F���ł��ĂȂ��ƃ��U�C�N���ǐ����Ȃ�
				}
				else if (mask_type == O) {
					double degree = atan2(LElbow[i].y - LWrist[i].y, LElbow[i].x - LWrist[i].x);
					degree = 160 - degree * (180 / PI);
					cv::Point2f center(mask_img.cols*0.5, mask_img.rows*0.5);
					const cv::Mat affine_matrix = cv::getRotationMatrix2D(center, degree, 1.0);
					cv::Mat dst_img;
					cv::warpAffine(mask_img, dst_img, affine_matrix, mask_img.size());
					paste(frame, dst_img, LWrist[i].x + 20, LWrist[i].y - 50, 200, 200);
				}
				else if(mask_type != B){
					if (mask_height > 0 && head_top[i].x > 0 && head_top[i].y > 0)
						paste(frame, mask_img, head_top[i].x - mask_width / 2, head_top[i].y - 10, mask_width, mask_height + 50);
				}

				cv::imshow(mWindowName, frame);
				if (waitKeyValue != -1)
					cv::waitKey(waitKeyValue);
			}
		}
        catch (const std::exception& e)
        {
            error(e.what(), __LINE__, __FUNCTION__, __FILE__);
        }
    }
}