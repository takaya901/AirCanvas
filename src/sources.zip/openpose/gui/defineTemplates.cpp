#include <openpose/gui/headers.hpp>

namespace op
{
    DEFINE_TEMPLATE_DATUM(WGui);
    DEFINE_TEMPLATE_DATUM(WGuiInfoAdder);
}
